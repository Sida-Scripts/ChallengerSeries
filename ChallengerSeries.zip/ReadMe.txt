=== Install Instructions ===

1. Extract the script to your BoL/Scripts folder.
2. Reload BoL
3. Click the "Custom Scripts" tab and enable "ChallengerSeries.lua"
4. Start a custom game.

=== Requires Sida's Auto Carry ===

This script requires Sida's Auto Carry. More information here http://forum.botoflegends.com/topic/6584-

=== More Information ===

For more information about the script please visit the forum thread at https://forum.botoflegends.com/topic/64012-